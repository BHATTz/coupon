# Coupon

Coupon project from Infobeckons based on laravel php framework.

## System Requirements

PHP : ^8.2 <br>
Node : ^20.9 <br>
Laravel : ^11.0 <br>
Composer : ^2.6 <br>
Database : Mysql(^10.0) <br>

## Installation

Install with below commands

```bash
composer install
```

```bash
npm install
```

##  Usage

```bash
php artisan serve
```

```bash
npm run dev
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first
to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

[MIT](https://choosealicense.com/licenses/mit/)